# Where have all the configurations gone?

Marlin configurations for specific machines are now maintained in their own repository at:

## https://github.com/MarlinFirmware/Configurations/tree/bugfix-2.0.x

Configuration files for use with the nightly `bugfix-2.0.x` branch can be downloaded from:

## https://github.com/MarlinFirmware/Configurations/archive/bugfix-2.0.x.zip
